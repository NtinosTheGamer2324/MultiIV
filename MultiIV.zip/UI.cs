﻿using IVSDKDotNet;
using IVSDKDotNet.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace MultiIV
{
    public class UI
    {
        private bool g_ShowDisconnected = false;

        public void ShowDisconnectedUI()
        {
            g_ShowDisconnected = true;
        }

        public void HideDisconnectedUI()
        {
            g_ShowDisconnected = false;
        }

        public void RenderUIDisconnected(DiscordRPC discordRpc)
        {
            if (g_ShowDisconnected)
            {
                ImGuiIV.SetNextWindowSize(new Vector2(440, 220), eImGuiCond.Once);
                ImGuiIV.SetNextWindowPos(new Vector2(100, 100), eImGuiCond.Once);

                // Added a unique ImGui ID suffix "##DisconnectedWindow" to avoid title collision with Main menu
                bool open = true;
                ImGuiIV.Begin("Disconnected##DisconnectedWindow", ref open, eImGuiWindowFlags.None);

                ImGuiIV.Text("You have been disconnected from this session.");

                if (ImGuiIV.Button("Quit"))
                {
                    discordRpc?.StopPresence();
                    Environment.Exit(0);
                }

                ImGuiIV.End();
            }
        }
    }
}