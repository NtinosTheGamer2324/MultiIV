// ============================ NetworkManager.cs ============================
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using IVSDKDotNet;

namespace MultiIV
{
    public class NetworkManager
    {
        // ── Public state ────────────────────────────────────────────────────────
        public bool IsConnected { get; private set; }
        public int MyPlayerId { get; private set; } = -1;

        public event Action<int, string, float, float, float, float, float> OnPlayerUpdate; // id, name, x, y, z, heading, speed
        public event Action<int> OnPlayerLeft;
        public event Action<int> OnJoinAccepted;
        public event Action<string, string> OnChatMessage;   // sender, message
        public event Action<string> OnKicked;        // reason
        public event Action OnDisconnected;          // fired on ANY disconnect path (manual, kick, or error)
        public event Action<int, string, uint, float, float, float, float, float, float>
            OnPlayerVehicleUpdate;   // id, name, modelHash, x,y,z, heading, pedHealth, vehHealth

        public event Action<int> OnPlayerExitVehicle;   // id

        public event Action<int, uint, float, float, float, float>
            OnPlayerWeaponFire;   // id, weaponHash, x, y, z, heading

        // ── Private ─────────────────────────────────────────────────────────────
        private UdpClient _udp;
        private IPEndPoint _server;
        private Thread _receiveThread;
        private volatile bool _running;

        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

        // ── Connect / Disconnect ────────────────────────────────────────────────

        public void Connect(string host, int port, string playerName)
        {
            if (IsConnected) return;
            try
            {
                _udp = new UdpClient(0);

                // Resolve hostname — also handles raw IPs like "127.0.0.1"
                IPAddress[] addrs = Dns.GetHostAddresses(host);
                if (addrs.Length == 0)
                    throw new Exception("Could not resolve hostname: " + host);

                _server = new IPEndPoint(addrs[0], port);

                _running = true;
                _receiveThread = new Thread(ReceiveLoop) { IsBackground = true };
                _receiveThread.Start();

                SendPacket(new Dictionary<string, object>
                {
                    ["Type"] = "JoinRequest",
                    ["PlayerName"] = playerName
                });

                IsConnected = true;
                IVGame.Console.PrintWarning($"[MultiIV] Connecting to {host}:{port} as '{playerName}'...");
            }
            catch (Exception ex)
            {
                IVGame.Console.PrintError("[MultiIV] Connect failed: " + ex.Message);
                Cleanup();
                OnDisconnected?.Invoke();
            }
        }

        public void Disconnect()
        {
            if (!IsConnected) return;
            if (MyPlayerId != -1)
            {
                try
                {
                    SendPacket(new Dictionary<string, object>
                    {
                        ["Type"] = "Disconnect",
                        ["PlayerId"] = MyPlayerId
                    });
                }
                catch { }
            }
            Cleanup();
            IVGame.Console.PrintWarning("[MultiIV] Disconnected.");
            OnDisconnected?.Invoke();
        }

        // Called internally when the server kicks us — no outbound packet needed
        private void DisconnectSilent()
        {
            Cleanup();
            OnDisconnected?.Invoke();
        }

        private void Cleanup()
        {
            _running = false;
            IsConnected = false;
            MyPlayerId = -1;
            try { _udp?.Close(); } catch { }
            _udp = null;
        }

        // ── Send ────────────────────────────────────────────────────────────────

        public void SendPositionUpdate(int playerId, float x, float y, float z, float heading, float speed = 0f)
        {
            SendPacket(new Dictionary<string, object>
            {
                ["Type"] = "PositionUpdate",
                ["PlayerId"] = playerId,
                ["X"] = x,
                ["Y"] = y,
                ["Z"] = z,
                ["Heading"] = heading,
                ["Speed"] = speed
            });
        }

        public void SendChatMessage(int playerId, string message)
        {
            SendPacket(new Dictionary<string, object>
            {
                ["Type"] = "ChatMessage",
                ["PlayerId"] = playerId,
                ["Message"] = message
            });
        }

        public void SendVehicleUpdate(
            int playerId,
            uint modelHash,
            float x, float y, float z, float heading,
            float pedHealth, float vehicleHealth)
        {
            SendPacket(new Dictionary<string, object>
            {
                ["Type"] = "VehicleUpdate",
                ["PlayerId"] = playerId,
                ["ModelHash"] = (long)modelHash,   // JSON has no uint; cast to long
                ["X"] = x,
                ["Y"] = y,
                ["Z"] = z,
                ["Heading"] = heading,
                ["PedHealth"] = pedHealth,
                ["VehicleHealth"] = vehicleHealth
            });
        }

        public void SendWeaponFire(
            int playerId, uint weaponHash,
            float x, float y, float z, float heading)
        {
            SendPacket(new Dictionary<string, object>
            {
                ["Type"] = "WeaponFire",
                ["PlayerId"] = playerId,
                ["WeaponHash"] = (long)weaponHash,   // JSON has no uint; cast to long
                ["X"] = x,
                ["Y"] = y,
                ["Z"] = z,
                ["Heading"] = heading
            });
        }

        private void SendPacket(Dictionary<string, object> packet)
        {
            if (_udp == null) return;
            try
            {
                byte[] data = Encoding.UTF8.GetBytes(Json.Serialize(packet));
                _udp.Send(data, data.Length, _server);
            }
            catch (Exception ex)
            {
                IVGame.Console.PrintError("[MultiIV] Send failed: " + ex.Message);
            }
        }

        // ── Receive loop ────────────────────────────────────────────────────────

        private void ReceiveLoop()
        {
            while (_running)
            {
                try
                {
                    IPEndPoint remote = null;
                    byte[] data = _udp.Receive(ref remote);
                    string json = Encoding.UTF8.GetString(data);

                    var packet = Json.Deserialize<Dictionary<string, object>>(json);
                    if (packet == null || !packet.ContainsKey("Type")) continue;

                    HandlePacket(packet["Type"] as string, packet);
                }
                catch (SocketException) { break; }
                catch (Exception ex)
                {
                    if (_running)
                        IVGame.Console.PrintError("[MultiIV] Receive error: " + ex.Message);
                }
            }
        }

        private void HandlePacket(string type, Dictionary<string, object> packet)
        {
            switch (type)
            {
                case "JoinAccepted":
                    MyPlayerId = Convert.ToInt32(packet["AssignedPlayerId"]);
                    OnJoinAccepted?.Invoke(MyPlayerId);
                    IVGame.Console.PrintWarning("[MultiIV] Joined! ID: " + MyPlayerId);
                    break;

                case "WorldStateUpdate":
                    HandleWorldState(packet);
                    break;

                case "PlayerLeft":
                    OnPlayerLeft?.Invoke(Convert.ToInt32(packet["PlayerId"]));
                    break;

                case "ChatMessage":
                    string sender = packet.ContainsKey("Sender") ? packet["Sender"] as string : "?";
                    string message = packet.ContainsKey("Message") ? packet["Message"] as string : "";
                    OnChatMessage?.Invoke(sender, message);
                    break;

                case "Kicked":
                    string reason = packet.ContainsKey("Reason") ? packet["Reason"] as string : "Kicked by server.";
                    DisconnectSilent();
                    OnKicked?.Invoke(reason);
                    break;

                case "WeaponFire":
                    int wfId = Convert.ToInt32(packet["PlayerId"]);
                    if (wfId == MyPlayerId) break; // don't play back our own shot

                    uint wHash = packet.ContainsKey("WeaponHash")
                        ? (uint)Convert.ToInt64(packet["WeaponHash"]) : 0;
                    float wx = Convert.ToSingle(packet["X"]);
                    float wy = Convert.ToSingle(packet["Y"]);
                    float wz = Convert.ToSingle(packet["Z"]);
                    float wh = Convert.ToSingle(packet["Heading"]);

                    OnPlayerWeaponFire?.Invoke(wfId, wHash, wx, wy, wz, wh);
                    break;
            }
        }

        private void HandleWorldState(Dictionary<string, object> packet)
        {
            if (!packet.ContainsKey("Players")) return;
            var players = (System.Collections.ArrayList)packet["Players"];

            foreach (object obj in players)
            {
                var p = (Dictionary<string, object>)obj;

                int id = Convert.ToInt32(p["PlayerId"]);
                float x = Convert.ToSingle(p["X"]);
                float y = Convert.ToSingle(p["Y"]);
                float z = Convert.ToSingle(p["Z"]);
                float heading = Convert.ToSingle(p["Heading"]);
                float health = p.ContainsKey("Health") ? Convert.ToSingle(p["Health"]) : 100f;
                float speed = p.ContainsKey("Speed") ? Convert.ToSingle(p["Speed"]) : 0f;
                string name = p.ContainsKey("PlayerName") ? p["PlayerName"] as string : $"Player{id}";

                if (id == MyPlayerId) continue;

                if (p.ContainsKey("Vehicle") && p["Vehicle"] is Dictionary<string, object> veh)
                {
                    uint modelHash = (uint)Convert.ToInt64(veh["model_hash"]);
                    float vehicleHealth = Convert.ToSingle(veh["vehicle_health"]);

                    OnPlayerVehicleUpdate?.Invoke(
                        id, name, modelHash,
                        x, y, z, heading,
                        health, vehicleHealth);
                }
                else
                {
                    // On foot — make sure any vehicle they were in gets removed
                    OnPlayerExitVehicle?.Invoke(id);
                    OnPlayerUpdate?.Invoke(id, name, x, y, z, heading, speed);
                }
            }
        }
    }
}